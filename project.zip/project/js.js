
function taga() {
    var x = document.getElementsByTagName('a');
    alert(x.length + " Anchor Tag.");
}
function tagimg() {
    var x = document.getElementsByTagName('img');
    alert(x.length + " Images Tsg.");
}
function taghed() {
    var x = document.getElementsByTagName('h2');
    alert(x.length + " Heading Tag.");
}
function tagpar() {
    var x = document.getElementsByTagName('p');
    alert(x.length + " Paragraph Tag.");
}
function tagdiv() {
    var x = document.getElementsByTagName('div');
    alert(x.length + " Div Tag.");
}
